# Task 007：首批工程骨架审核问题修复

文档版本：v1.0
更新日期：2026-10-22

## 1. 目标与授权

用户授权修复[独立审核R01–R04](../docs/workorders/skeleton_independent_review_2026-10-22.md)，补回归、重跑验证、保留现有工作与原证据，生成新交付基线并安排subagent复核。目标是让门禁正确判断包导入、启动失败有限时返回、探针精确校验200、完整恢复含空文件的交付源码。

只改工程检查、测试、证据工具和必要文档；不启动任务006、业务实现、数据库、外部Provider或部署。不改变业务语义、权限与分期。沿用任务005的SK-01–09范围，关联ARC-01/02/09及OPS-01/03的工程子集。

## 2. 基线与保留

修复前状态含新增的任务006及对应项目状态文字，已读取并保留。修复前所有191个已跟踪/未跟踪文件的内容与摘要保存在[initial.json](../docs/workorders/evidence/skeleton_fixes_2026-10-22/initial.json)及[initial-files.tar.gz](../docs/workorders/evidence/skeleton_fixes_2026-10-22/initial-files.tar.gz)。原交付/原审核证据不覆盖；原6个构建产物复制到本轮original-artifacts，随后新构建产物另记录摘要。

依据：AGENTS v1.1、00-01工程基线v1.1、任务005 v1.0及独立审核v1.0；本轮不修订这些历史交付文件。新基线用完整源码快照作为重定位依据，差异文件仅辅助阅读。

## 3. 修复与需求—测试追踪

| 问题/需求 | 修复 | 需求导向的回归及反例 |
| --- | --- | --- |
| R01 / SK-02 | scripts/check_architecture.py统一按包名相等或点分子成员判断边界 | test_boundaries.py新增20项：Application具体适配器/装配包、Knowledge反向依赖的3种导入写法；合法ports包/成员允许，ports_private仍拒绝；原检查器实际12失败/21通过，新版本全部通过 |
| R02 / SK-05 | tests/unit/process_support.py以单一monotonic截止时间和非阻塞字节读取等待完整启动行；上下文统一清理进程与管道 | 正常Worker启停保留；无输出、仅半行均0.2秒期限失败并reap；提前退出报错并reap；临时真实Worker移除启动日志，原生命周期用例在10秒期限内失败，不再无限等待 |
| R03 / SK-04 | test_startup显式断言200；wheel smoke的probe_live显式校验实际HTTP200，日志用实际live/ready状态 | 临时路由201导致原应用测试失败；网络探针实际本机HTTP服务器分别返回200/201，正例通过、反例拒绝 |
| R04 / SK-09 | scripts/delivery_snapshot.py新增完整源码tar+SHA清单；输出目录必须新建，验证文件集合与内容完整一致，不修改旧补丁 | 重构空.gitkeep、二进制、无末尾换行文本；缺少/篡改/多余清单均拒绝；已有基线拒绝覆盖。新交付全部源文件逐一重构核验 |

范围外的数据库事务/权限/人工内容/固定版本及业务端到端保持未验证，不用工程测试替代。

## 4. 验证与证据

证据统一在[skeleton_fixes_2026-10-22](../docs/workorders/evidence/skeleton_fixes_2026-10-22)，新日志不覆盖旧文件。

| 命令/检查 | 结果 |
| --- | --- |
| 新R01用例运行原检查器 | 12失败、21通过，确认回归能复现缺陷；r01-before.txt |
| python3 scripts/engineering.py check | Ruff/格式/Mypy通过；早期56后端、15契约、2前端通过；check.txt；最终隔离基线58后端/15契约/2前端见isolated-check.txt |
| python3 scripts/verify_skeleton_delivery.py | 干净环境安装构建、锁漂移/缺锁拒绝、wheel真实网络探针和SIGTERM完成；clean-delivery.txt |
| python3 scripts/engineering.py build | 后端sdist/wheel与前端静态构建通过；build.txt |
| python3 scripts/engineering.py e2e | 2项浏览器预览用例通过；e2e.txt |
| python3 docs/workorders/evidence/skeleton_fixes_2026-10-22/regression-mutations.py | 临时副本变异反例，结果见regression-mutations.txt；不修改业务源码 |
| python3 scripts/delivery_snapshot.py verify --directory docs/workorders/evidence/skeleton_fixes_2026-10-22/baseline | 新完整源码基线校验；并行变更的隔离方式、全量结果与subagent复核见收口记录 |

Node24/npm11沿用此前独立临时工具环境；依赖锁未修改。重建仅用于本批交付验证，无真实模型、邮件、论文源或数据库访问。保留上游Starlette/httpx弃用警告。

## 5. 自审、subagent复核与人工接受

源码快照生成器纳入统一Ruff检查及后端回归；旧证据内容的保留和全量重构由独立subagent再次核验。源码快照不包含证据目录以避免递归；完整证据由另一个清单关联。

独立复核及最终基线见[修复收口记录](../docs/workorders/skeleton_fixes_review_2026-10-22.md)。设计依据未变；本批修复和自动验证不代表完整业务验收，人工接受仍待明确记录。无新的业务决定问题。
