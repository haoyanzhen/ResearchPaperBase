import sys

import uvicorn
from fastapi import FastAPI
from pydantic import ValidationError

from rpb.api.health import router
from rpb.bootstrap.config import Settings


def create_app() -> FastAPI:
    Settings.load()
    app = FastAPI(title="RPB engineering skeleton", docs_url=None, redoc_url=None, openapi_url=None)
    app.include_router(router)
    return app


def main() -> None:
    try:
        settings = Settings.load()
    except ValidationError:
        print("Invalid process configuration; startup refused.", file=sys.stderr)
        raise SystemExit(2) from None
    uvicorn.run(create_app(), host=settings.host, port=settings.port, access_log=False)


if __name__ == "__main__":
    main()
