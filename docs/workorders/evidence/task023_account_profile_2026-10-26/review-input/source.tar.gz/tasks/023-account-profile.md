# Task023：个人账户资料维护

文档版本：v1.0
更新日期：2026-10-26

## 1. 目标与授权

用户2026-10-26接受M-P0-03并授权下一阶段直到里程碑或未明确设计。下一可使用切片为M-P0-04个人资料维护：本人邮箱/显示名编辑、再次读取与登录、冲突和失败恢复。仅FR001本人资料、04 UserPatch；不实现管理员治理、头像上传、密码更改、配置或P1。达到本完整业务成果后提交单一验收包。

## 2. 依据与基线

01 FR001及2026-10-25身份规则；04/04-01 §1/2 UserPatch省略保持、display_name可null、未知字段拒绝，修订428/412；03-01 P06a；08本人权限；07隔离事务。沿用账号治理锁使注册和邮箱变更的跨字段唯一性原子成立。当前显示名硬编码null、没有PATCH /me。原工作区全部保留；before快照包含未提交/未跟踪文件。M-P0-03接受绑定task022原delivery。

## 3. 修改落点

AccountPort/Store、账户路由、显示名列迁移、BusinessApp资料入口、真实PG/HTTP/浏览器需求测试；状态和使用说明。沿用当前会话，不新增隐式登出、邮箱验证或通知策略。用户名/权限/密码不允许更新。

## 4. 验收规格

AP01：邮箱/显示名部分修改，省略保持、null清空显示名、显示名strip后长度、邮箱展示原文及归一化登录键、空修改不推进修订，重读一致；保持密码/权限/项目/他人信息。
AP02：归一化跨字段身份唯一、同账号用户名邮箱可相同；新邮箱可登录，旧邮箱不能登录（除非仍为用户名）；注册/编辑和并发编辑竞争仅一份成功。
AP03：本人身份/禁用/CSRF/origin；缺修订428、陈旧412、未知/只读/null邮箱/坏格式422；失败不写。
AP04：真实事务故障回滚；迁移保留已有账号、metadata一致、非空显示名降级拒绝及并发保护。
AP05：浏览器显示/编辑/取消/保存/刷新；明确校验可纠正、冲突/未知结果保留草稿并显式核查，跨标签换账号不可提交旧草稿；桌面与窄屏。

需求到用例：AP01→test_ap01_partial_clear_noop_and_protected_facts；AP02→test_ap02_identity_uniqueness_and_login / concurrent_edits_have_one_winner / identity_claim_serializes_with_other_writers；AP03→test_ap03_invalid_rejected_without_writes / revision_and_authorization；AP04→test_ap04_write_failure_rolls_back / migration_preserves_data_and_guards_downgrade / committed_profile_prevents_waiting_downgrade / database_rejects_oversized_display_name；均在backend/tests/integration/test_account_profile.py。AP05→test_account_profile_browser.py的编辑/取消/保存/重读（桌面/窄屏）、冲突/丢响应、换账号场景。明确校验纠正浏览器场景待补，不宣称已覆盖。

## 5. 验证计划与证据

隔离临时PG17及真实HTTP/Chromium，沿用engineering.py integration/check/build。无外部LLM/邮件调用。证据目录docs/workorders/evidence/task023_account_profile_2026-10-26。未执行项不得标通过。

## 6. 业务决策与里程碑

当前无新增业务决定。M-P0-04范围为AP01–05，不代表完整账号治理或配置。待工程收口后验收。

## 7. 交付报告

待完成。

## 8. 检查点

流程v1.7；S1完成、S2进行中，S3–S7待执行。授权来自本轮用户消息。下一动作实现需求测试与最小代码，然后独立审查。配置设计核查不扩大本里程碑。
