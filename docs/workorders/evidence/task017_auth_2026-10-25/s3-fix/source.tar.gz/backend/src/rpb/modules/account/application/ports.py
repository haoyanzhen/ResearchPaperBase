"""Account transaction port: implementations own one atomic operation per call."""

from typing import Any, Protocol


class AccountError(Exception):
    def __init__(self, code: str, status: int) -> None:
        self.code, self.status = code, status
        super().__init__(code)


class AccountPort(Protocol):
    def csrf(self, token: str | None) -> tuple[str, str]: ...
    def register(
        self, token: str, csrf: str, username: str, email: str, password: str
    ) -> dict[str, Any]: ...
    def login(
        self, token: str, csrf: str, identifier: str, password: str
    ) -> tuple[dict[str, Any], str]: ...
    def logout(self, token: str, csrf: str) -> None: ...
    def read_self(self, token: str) -> dict[str, Any]: ...
