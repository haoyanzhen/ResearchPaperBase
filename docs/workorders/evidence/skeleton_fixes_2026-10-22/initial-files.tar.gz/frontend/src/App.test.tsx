import { render, screen, fireEvent } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';
import { App } from './App';
describe('engineering preview scope', () => {
  it('labels unavailable functionality and prevents writes', () => {
    const fetch = vi.spyOn(globalThis, 'fetch');
    render(<App />);
    expect(screen.getByRole('heading', { name: 'Projects' })).toBeVisible();
    expect(screen.getByText('当前为工程骨架预览，未连接业务数据。')).toBeVisible();
    fireEvent.click(screen.getByRole('button', { name: '创建 Project（尚未实现）' }));
    expect(screen.getByRole('button', { name: '创建 Project（尚未实现）' })).toBeDisabled();
    expect(fetch).not.toHaveBeenCalled();
    fetch.mockRestore();
  });
  it('navigates locally without fabricating account or project state', () => {
    render(<App />);
    fireEvent.click(screen.getByRole('button', { name: '设置' }));
    expect(screen.getByRole('heading', { name: '设置' })).toBeVisible();
    expect(screen.getByRole('button', { name: '保存设置（尚未实现）' })).toBeDisabled();
    fireEvent.click(screen.getByRole('button', { name: 'Projects' }));
    expect(screen.getAllByRole('main')).toHaveLength(1);
    expect(screen.queryByText('Admin')).not.toBeInTheDocument();
  });
});
