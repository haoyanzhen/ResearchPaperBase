import { test, expect } from '@playwright/test';
for (const viewport of [{ width: 1280, height: 900 }, { width: 390, height: 844 }]) {
  test(`preview navigation and unavailable actions ${viewport.width}`, async ({ page }) => {
    await page.setViewportSize(viewport);
    const errors: string[] = [];
    const writes: string[] = [];
    page.on('pageerror', error => errors.push(error.message));
    page.on('request', request => { if (request.method() !== 'GET') writes.push(request.url()); });
    await page.goto('/');
    await expect(page.getByRole('heading', { name: 'Projects', exact: true })).toBeVisible();
    await expect(page.getByRole('button', { name: '创建 Project（尚未实现）' })).toBeDisabled();
    await page.keyboard.press('Tab');
    await expect(page.getByRole('link', { name: '跳到内容' })).toBeFocused();
    await page.getByRole('button', { name: '设置', exact: true }).click();
    await expect(page.getByRole('heading', { name: '设置', exact: true })).toBeVisible();
    await expect(page.getByRole('button', { name: '保存设置（尚未实现）' })).toBeDisabled();
    await page.getByRole('button', { name: 'Projects', exact: true }).click();
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
    await expect(page.getByRole('main')).toHaveCount(1);
    await page.screenshot({ path: `test-results/shell-${viewport.width}.png`, fullPage: true });
    expect(errors).toEqual([]);
    expect(writes).toEqual([]);
  });
}
