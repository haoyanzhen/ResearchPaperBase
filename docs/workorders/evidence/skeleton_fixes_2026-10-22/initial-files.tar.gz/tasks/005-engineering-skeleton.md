# Task 005：第一批可验证工程骨架

文档版本：v1.0
更新日期：2026-10-22

## 1. 目标与授权

用户于2026-10-22授权：按现有工程基线搭建第一批骨架，完成安装、启动、检查和构建验证，保留已有未提交修改并提交审核。

可观察结果：审核者能按README安装，在本机启动API、显式空闲Worker与前端预览，运行统一检查和构建；未接入的业务能力明确不可用。

范围：B08工程入口、A10本任务限定验收、模块包边界、进程配置、健康探针、空迁移链与失败保护、前端基础导航及预览。关联ARC-01/02/08/09/10、OPS-01/03的工程子集；不关闭这些用例的完整业务范围。

不含账号/Project业务实现、持久任务、业务迁移与UoW、文件/密钥适配器、真实PostgreSQL测试夹具、Graph-RAG、模型接入、生产部署。A04–A09、H01–H03维持原边界；本批不消费尚缺公共错误模型的业务接口，不需要先关闭它们。

## 2. 当前依据与精确基线

依据：AGENTS v1.1；00-01 v1.0 §2/3/5/6；00分层与05-01模块所有权；03 v1.25 §2/3的基础导航和单一主体原则；09工程隔离、证据与OPS要求；10 v1.7 §2.1/7。设计中完整Project Workspace需真实对象，本批只提供未连接业务数据的全局预览，不模拟Project绑定。

[初始清单](../docs/workorders/evidence/skeleton_2026-10-22/initial.json)保存HEAD、初始状态和文件摘要；[初始diff](../docs/workorders/evidence/skeleton_2026-10-22/initial.patch)与[初始内容快照](../docs/workorders/evidence/skeleton_2026-10-22/initial-files.tar.gz)包含已有未提交/未跟踪文件。修改前校验快照逐文件摘要。当前交付与构建摘要见[最终清单](../docs/workorders/evidence/skeleton_2026-10-22/final.json)，本次相对初始工作区的差异见[交付diff](../docs/workorders/evidence/skeleton_2026-10-22/delivery.patch)。它们不是人工批准记录。

初始仅有设计与契约工具，Python3.14.4已安装，系统Node25不符合基线，Docker daemon不可用。通过独立临时工具目录安装Node24/npm11，未改全局Node、Docker服务、业务配置或旧数据。

## 3. 修改落点与工程取舍

| 落点 | 职责和限制 |
| --- | --- |
| backend/src/rpb | 六个业务模块的domain/application包边界，bootstrap/API/Execution/Knowledge/Agent/Adapters包；业务包仅明确保留位置，无通用假实现 |
| backend/src/rpb/bootstrap | 类型化进程配置、API和Worker装配；仅本机development/test；无数据库/模型隐式回退 |
| backend/src/rpb/api/health.py | 无对象信息的live=200、ready=503；无业务路由、API文档或伪造P0 OpenAPI |
| backend/migrations | 单一Alembic链入口，无业务revision；执行迁移立即拒绝，不读业务连接配置 |
| frontend/src | 单一全局导航与main，Projects/设置预览；未实现写操作disabled，不显示虚构账号或管理员入口 |
| frontend/e2e | 对构建后的预览进行真实浏览器检查；不是业务端到端验收 |
| scripts/engineering.py | install/check/build/api/worker/ui/e2e/integration/migration-history统一入口 |
| scripts/verify_skeleton_delivery.py | 临时干净副本安装构建、锁缺失/漂移反例、隔离入口拒绝、安装wheel的网络探针和停机 |
| scripts/check_architecture.py | 静态导入图及违规负例；约束Domain纯Python、Application不依赖ORM/HTTP、具体适配器仅装配处选择、禁止archive |
| README与现行入口 | 仅同步工程命令、实际范围和证据，不变更业务规则或产品分期 |

Worker采用显式 `--idle`，默认执行模式拒绝，避免把空循环宣称持久队列。API不因存活而宣称业务就绪；真实依赖启用后须替换ready逻辑并增加对应成功/失败测试。迁移入口采用硬拒绝，真实隔离目标/迁移协议未交付前不能误运行。没有为了骨架提前定义泛化Repository或任意JSON业务端口。

前端浏览器用例放在frontend/e2e，复用同一Node锁文件，工程基线同步路径。依赖补丁锁定于uv.lock/package-lock.json；构建后端使用精确Hatchling版本，wheel验证从uv.lock导出运行依赖后安装，不采用可编辑源码代替产物验证。

## 4. 验收规格与需求追踪

以下编号仅为本任务的工程子场景，不宣称覆盖对应ARC/OPS的全量业务规则。

| 需求与场景 | 输入/动作、预期可观察结果及禁止副作用 | 可执行测试与当前证据 |
| --- | --- | --- |
| SK-01 / OPS-01：可锁定安装构建 | 干净临时目录无venv/node_modules，install和build成功；修改Python项目版本/React依赖后locked/ci拒绝；缺锁先拒绝，不改当前工作区锁 | scripts/verify_skeleton_delivery.py；clean-delivery.txt、install.txt、build.txt |
| SK-02 / ARC-01/02：模块依赖方向 | 当前源码导入图通过；Domain导入ORM或相对外层、Application导入具体适配器/其他模块私有领域、Knowledge反向导入Agent、API绕过应用、archive及动态导入负例拒绝；允许的依赖通过 | backend/tests/architecture/test_boundaries.py 全部用例；check.txt |
| SK-03 / ARC-08、OPS-01：配置安全失败 | 缺配置使用无存储的本地进程默认；端口上下界通过；越界/无效端口、外部绑定、production和未支持RPB变量拒绝；启动错误不泄露标记值 | test_config_has_no_storage_or_provider_fallback、test_config_valid_boundaries、test_invalid_or_unimplemented_configuration_refused、test_api_rejects_configuration_without_leaking_values；check.txt |
| SK-04 / ARC-09/10：存活与就绪分离 | API无模型/数据库启动；live只返回alive，ready固定503；业务GET/POST及docs/openapi返回404；安装wheel启动、实际HTTP探测及SIGTERM完成关闭，无业务写入 | test_probes_and_no_business_routes；verify_skeleton_delivery.py；check.txt、clean-delivery.txt |
| SK-05 / ARC-09：Worker生命周期 | 默认执行拒绝；显式idle启动报告未就绪，SIGTERM正常停止；不领取或完成任务 | test_worker_refuses_task_execution、test_worker_idle_lifecycle；check.txt |
| SK-06 / OPS-01：缺持久化隔离时拒绝 | 即使提供合成业务DATABASE_URL，migration/integration也拒绝，不连接、不回退、不回显标记；迁移history为空 | test_migration_refuses_even_with_business_configuration；verify_skeleton_delivery.py；check.txt、clean-delivery.txt、migration-history.txt |
| SK-07 / 03基础导航：诚实可操作预览 | Projects/设置本地切换，功能未接入提示可见，创建/保存不可用，无伪造业务状态与网络写入；main唯一 | frontend/src/App.test.tsx；check.txt |
| SK-08 / 03窄屏与键盘工程子集 | 1280/390宽度无页面横向溢出，Tab可到跳转内容入口，切换页面成功，无浏览器异常/写请求，截图可审 | frontend/e2e/shell.spec.ts；e2e.txt、shell-1280.png、shell-390.png |
| SK-09 / OPS-03：保留工作与证据绑定 | 保留已有变更；本批变更有相对初始diff与摘要；只修改必要入口，契约JSON和其检查器保持原内容 | initial.json、initial-files.tar.gz、delivery.patch、final.json；documentation.txt |
| 受影响既有契约工具 | OpenAPI/schema/覆盖无漂移，原15项回归通过；本次不改变机器契约，不声明全HTTP协议验收 | scripts/tests/test_api_contracts.py及check_api_contracts.py；check.txt |

无业务写路径，业务并发、去重、权限、版本绑定和人工内容保护没有执行入口，本批不以空断言冒充覆盖；仍由TRACK-004/007/008/012/018/019/021跟踪。真实PostgreSQL commit/race验证需后续切片，当前integration明确非零退出。架构检查只分析静态Python导入，不证明未来运行时写入所有权。

## 5. 执行证据与复现

证据目录：[skeleton_2026-10-22](../docs/workorders/evidence/skeleton_2026-10-22)。命令在仓库根执行，Node24在PATH；本机临时工具位于 `/tmp/rpb-skeleton-tools/node_modules/.bin`，不是跨机器前置路径。跨机器按README选择运行时。

| 命令 | 实际结果与范围 |
| --- | --- |
| python3 scripts/engineering.py install | 通过；本机环境按锁安装，契约独立环境按原requirements安装 |
| python3 scripts/engineering.py check | 通过；Ruff/格式/Mypy，26项后端、15项契约、2项前端测试；静态契约通过，未传旧审查基线，因此不宣称历史兼容检查 |
| python3 scripts/engineering.py build | 通过；后端sdist/wheel、前端静态产物 |
| python3 scripts/verify_skeleton_delivery.py | 通过；新临时环境安装构建、锁缺失/漂移拒绝、integration拒绝、锁定依赖的wheel安装及实际API启停；临时目录已清理 |
| python3 scripts/engineering.py migration-history | 通过；空链，无业务迁移执行 |
| python3 scripts/engineering.py e2e | 通过；2项真实Chromium浏览器用例及桌面/窄屏截图，人工式视觉检查未见布局问题；仅工程预览范围 |

开发中发现并修复：Testing Library类型不接受Playwright式exact选项；独立契约安装须解析requirements依赖；脚本格式配置统一；锁负例须实际触发锁不一致而非离线缓存失败。Uvicorn SIGTERM完成清理后可返回信号码，测试同时断言shutdown complete及允许的信号退出，不把正常信号当业务故障。修复后重跑当前检查；无删除必要反例或修改业务要求。

剩余非阻断警告：上游Starlette提示httpx TestClient适配器未来弃用；本次锁定组合仍通过真实进程测试，未屏蔽警告。契约工具原requirements的传递依赖未锁定，其本次准确版本见versions.txt；后续契约工具维护另行处理。浏览器下载由Playwright管理用户缓存，不属于业务服务访问。

## 6. 决策、限制与人工审核

本批无待裁决业务变更。数据库、迁移、配置管理、账号、Project、持久Worker、解析、知识版本、Graph-RAG及生产恢复未实现；ready=503是预期限制，不能作为可部署业务系统。依赖下载访问公开软件仓库；无真实LLM、论文源、邮件、旧数据库或旧文件操作。

人工审核建议：先复现README命令，查看两张截图；抽查config拒绝路径、health就绪状态、worker默认拒绝、迁移保护、架构反例及锁漂移证据，再确认本批范围是否接受。后续业务切片另行授权，不由通过检查推定。

设计依据：已核对；骨架代码：已实现；自动验证：按第5节逐项记录；人工接受：**待审核**。审核者、日期、接受基线与范围、问题处置由人工结论补录。
