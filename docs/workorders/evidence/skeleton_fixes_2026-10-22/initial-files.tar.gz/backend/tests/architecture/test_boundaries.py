import importlib.util
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[3]
spec = importlib.util.spec_from_file_location(
    "architecture", ROOT / "scripts/check_architecture.py"
)
assert spec and spec.loader
checker = importlib.util.module_from_spec(spec)
spec.loader.exec_module(checker)


@pytest.mark.parametrize(
    ("path", "source"),
    [
        ("rpb/modules/project/domain/model.py", "from sqlalchemy import Table"),
        ("rpb/modules/project/domain/model.py", "from ..application import commands"),
        ("rpb/modules/project/application/use_case.py", "from rpb.adapters import database"),
        (
            "rpb/modules/project/application/use_case.py",
            "from rpb.modules.review.domain import model",
        ),
        ("rpb/knowledge/read.py", "from rpb.agents import generate"),
        ("rpb/api/routes.py", "from rpb.modules.project.domain import model"),
        ("rpb/api/routes.py", "import archive.maybe_useful"),
        ("rpb/modules/project/domain/model.py", "__import__('sqlalchemy')"),
    ],
)
def test_forbidden_dependencies(path, source):
    assert checker.violations(path, source)


@pytest.mark.parametrize(
    ("path", "source"),
    [
        ("rpb/modules/project/domain/model.py", "from dataclasses import dataclass"),
        ("rpb/modules/project/application/use_case.py", "from ..domain import model"),
        ("rpb/bootstrap/api.py", "from rpb.adapters import database"),
        ("rpb/agents/service.py", "from rpb.knowledge import ports"),
    ],
)
def test_allowed_dependencies(path, source):
    assert not checker.violations(path, source)


def test_actual_import_graph():
    checker.main()
