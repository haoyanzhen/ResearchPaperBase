# Task015：B02 Account基础物理模型与首条迁移

文档版本：v1.0
更新日期：2026-10-25

## 1. 目标与授权

用户授权：“继续按 project-delivery 流程推进 B02，核对已有任务单和前置依赖，确定首个物理模型与迁移切片，完成本轮交付、自验及独立审查，再提交我审核。”本单负责S1–S3交付，再交S4；后续任务未授权。

核对tasks/001–014，无B02执行单。task004为示例；task009/013为规划；task014仅Project.Create机器契约。Project.owner依赖Account身份，因此本轮选Account聚合的基础持久记录为先行切片，不建缺失Account外键的Project表。A02逻辑持久化及工程基线有可用规范，task005 A10已限定接受；不依赖A05待接受部分，也不消费A06/A08/A09资料/知识规则。本轮不把A02文档核对冒充整份人工接受。

可观察结果：显式运行隔离PostgreSQL 17测试后，版本化迁移建立Account表，独立连接可读取已提交身份与状态；规范化键重复被数据库拒绝，失败迁移可诊断及重跑，测试进程结束不留临时数据库。关联TRACK-007a/b/c，仅Account基础字段/迁移子集。

不包含注册/登录/会话、首位或最后管理员裁决、账户删除、规范化算法、密码哈希服务、HTTP错误映射、Project及知识资产、生产目标或旧数据迁移。不是FR-001、完整Account聚合或整体B02验收。

## 2. 依据与入场基线

已读AGENTS、PROJECT_STATUS v1.60、设计索引、IMPLEMENTATION_ENTRY v1.6及B02工作清单；需求01 FR-001、领域02 v1.26 Account聚合、03-01账户页、04-01账户操作、05应用顺序、07 v1.13 §3/4/9、08 v1.9 §2、工程基线00-01 §5。

| 规范子条目 | 本轮落实及所有者 |
| --- | --- |
| 07 §3身份UUID、不透明revision、UTC时间；Account最小事实 | adapters.account SQLAlchemy元数据；账号身份、原始显示字段、规范化键、hash、enabled/admin、修订、时间。 |
| 07 §3登录标识唯一；04-01注册重复冲突 | username_key/email_key各自非空唯一，使用C精确比较；物理拒绝与约束名可诊断。规范化及跨用户名/邮箱的歧义解析留注册切片，不自行规定大小写规则。 |
| 08 §2/FR-001密码不明文保存 | 只有password_hash列，无原密码或会话token列；测试用合成hash占位。数据库Text不能判断字符串是否真实hash，真实哈希及拒绝明文输入须后续认证应用验证，本轮不宣称密码安全端到端完成。 |
| 07版本化迁移；00-01 §5/AGENTS隔离 | 唯一Alembic链、真实PG17、显式独立实例/库/角色、连接后核验运行标识、内部commit与物理清理；不读取业务连接。 |

入场[200文件快照](../docs/workorders/evidence/task015_b02_2026-10-25/before/source-manifest.json)及同目录source.tar.gz包括所有既有未提交/未跟踪产物；HEAD 7ba2a2c638500eaa43f2137d16a6a0686b663630。此前空迁移链、integration明确拒绝；未恢复旧SQL或旧数据。

## 3. 修改落点与工程选择

- `backend/src/rpb/adapters/account.py`：存储元数据，API DTO不充当ORM对象；无应用接入、无create_all调用。
- `backend/migrations/versions/0001_account.py`：冻结首版DDL；不导入可变模型；空表可降级，有数据拒绝而保留版本及数据。
- `backend/migrations/env.py`：只消费显式Connection和运行ID，校验库/角色/标识/非管理员；无从环境创建连接的回退。
- `scripts/run_storage_tests.py`：临时PG17集群、SCRAM、0700根/0600凭据、无TCP监听；父夹具建库，子测试只获本次非管理员角色；停止失败保留目录供诊断。
- `scripts/engineering.py`、`backend/pyproject.toml`、conftest：默认无库检查与显式集成分开；缺目标失败；README记录适用命令。
- 集成测试、任务及状态：逐场景证据，保留所有原有骨架拒绝/无存储测试。

Account可变对象的revision由未来写入者在更新时提供新值；本轮测试其持久性，不宣称已实现CAS/不可复用历史。不可变知识修订和Project复合归属对本表不适用，仍由后续B02切片负责。enabled/is_admin无自动默认，物理存储不代替首位管理员治理。未建立未消费的Repository/UoW抽象。

技术参考：[PostgreSQL initdb](https://www.postgresql.org/docs/17/app-initdb.html)、[Alembic显式共享连接](https://alembic.sqlalchemy.org/en/latest/cookbook.html#sharing-a-connection-across-one-or-more-programmatic-migration-commands)；本项目采用版本化迁移，不采用create_all初始化。

## 4. 验收规格与需求追踪

测试路径统一为`backend/tests/integration/test_account_storage.py`，函数前缀`test_acNN_`对应下表；真实事务、约束及锁，不用SQLite/mock替代。

| 场景/规则 | 动作与可观察结果 | 禁止副作用/屏障 | 证据 |
| --- | --- | --- | --- |
| AC01 迁移与索引一致 | 从空库升级，metadata差异为空；重复升级保留已提交数据和revision head；核对列与检查约束 | 不重复建表、不丢数据、不加明文密码列 | integration日志 |
| AC02 最小事实持久化 | 服务端UUID/修订/UTC；commit后独立连接读更新状态/新修订/时间/合成hash | 不改变创建时间及身份 | 同上 |
| AC03 登录键唯一/事务 | 分别重复username_key/email_key，SQLSTATE23505及对应具名约束；同事务先写的其他行回滚 | 只留原先已提交行 | 同上 |
| AC04 必需键/hash | null和空字符串拒绝，无持久行 | 无部分提交 | 同上 |
| AC05 唯一性并发 | 两连接同键；观察pg_blocking_pids确定等待胜者事务后commit；败者23505 | 每种键只产生一行；8秒锁超时防挂起 | 同上 |
| AC06 降级保护 | 有数据拒绝，版本及行保持；空表down/up成功 | 不自动删账号数据 | 同上 |
| AC07 故障恢复 | CREATE之后故障注入，表与版本回滚，再upgrade成功 | 不留半迁移 | 同上 |
| AC08 错误运行标识 | 不匹配ID时拒绝DDL，原表/版本保持；核对角色无super/createDB/createRole | 不误迁移非本轮库 | 同上 |
| AC10 测试失败清理 | `test_fixture_cleanup.py`在真实建库后模拟子测试退出9/超时，两次均停止进程并移除根目录 | 内部建库commit不逃逸清理 | integration日志 |
| AC09 原骨架受影响边界 | 原test_startup及test_skeleton_requirements保留；默认integration及ambient DATABASE_URL拒绝且无连接；API/Worker保持无DB | 不借存储切片接入业务服务 | backend日志 |

未覆盖：规范化算法及登录歧义、哈希实现、权限、首位管理员并发、CAS、Session、Project归属、不可变修订、端到端；均不在本轮存储规格，不关闭对应项目需求。数据库唯一索引不证明注册完整行为。

## 5. 自验及证据

证据根：`docs/workorders/evidence/task015_b02_2026-10-25/`。当前执行证据：

| 命令（仓库根） | 实际结果/证据 |
| --- | --- |
| `python3 scripts/engineering.py integration --postgres-bin /opt/homebrew/opt/postgresql@17/bin` | [integration.log](../docs/workorders/evidence/task015_b02_2026-10-25/integration.log)：PG17.11，17通过；唯一库rpb_test_fddddd362eb54f8e9eb7479422fdc70b，server_stopped/root_removed=true。 |
| `python3 scripts/engineering.py check` | [check.log](../docs/workorders/evidence/task015_b02_2026-10-25/check.log)：执行中；ruff/mypy及82后端已通过，契约/前端结果待核对。 |
| `python3 scripts/engineering.py build` | [build.log](../docs/workorders/evidence/task015_b02_2026-10-25/build.log)：执行中。 |
| `python3 scripts/engineering.py migration-history` | 输出单head：base → 0001_account。 |

Node命令使用既有临时Node24工具PATH；后端使用uv --locked及Python3.14。首次ruff发现长行已格式化/修复；全部最终门禁须在交S4前通过。

本机原只有PG16且Docker daemon不可用；为符合已定PG17基线执行`brew install postgresql@17`，得到17.11；Homebrew同时更新依赖、初始化默认`/opt/homebrew/var/postgresql@17`但未启动服务，本轮不使用它，也未切换已链接PG16。集成夹具只使用`/tmp/rpb-db-*`新实例；真实测试凭据均为临时生成，无邮件/LLM/Provider请求。安装会留下二进制和Homebrew默认空集群，不将它们误称为测试残留或自行删除。

## 6. 人工审核

无新增业务政策待决；请求接受仅本单AC01–10限定存储交付。审核方式：运行README显式integration命令，观察唯一键/故障断言及最后`server_stopped/root_removed`；检查迁移env与夹具边界，确认范围没有被写成账户业务验收。

设计：已限定；代码：已实现待完整自验；自动验证：进行中；独立审查：待开始；人工接受：未收到。S5–S7须在本轮接受后执行。

## 7. 单一交付报告

本单为审核包，不另建重复报告。最终差异清单、执行日志、独立审查及内容快照将在交S4前填入；已知限制见第1/4/5节。

## 8. 顺序交付检查点

| 阶段 | 状态 | 依据 |
| --- | --- | --- |
| S1 | 已完成 | 用户授权B02首片；入场200文件快照；选择Account基础持久事实 |
| S2 | 进行中 | 实现/真实PG初次15用例通过，待最终回归和证据 |
| S3 | 待开始 | 必须独立subagent只读审查 |
| S4 | 待开始 | 等待具体审核包，不代填人工接受 |
| S5–S7 | 待开始 | 依赖S4接受 |

恢复时核对快照和任务记录，不将当前大量未提交内容视为本轮全部变更；只授权本任务，未授权后续backlog。
